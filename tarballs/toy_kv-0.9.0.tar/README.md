# toy_kv v0.9.0

Initial in-memory prototype release of key-value storage in Datara.

## Installation
```bash
dpm add sparks/toy_kv@0.9.0
```
