# crypto_core v0.9.0

Initial preview release of cryptographic primitives for the Datara programming language.

## Features
- `constant_time_eq`: Constant-time byte slice comparison to mitigate timing attacks.
- `rotl32`: 32-bit bitwise left rotation.

## Installation
```bash
dpm add sparks/crypto_core@0.9.0
```
